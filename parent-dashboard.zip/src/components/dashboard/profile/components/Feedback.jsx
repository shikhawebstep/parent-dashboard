import React from 'react'

const Feedback = () => {
  return (
    <div>
      
    </div>
  )
}

export default Feedback
