import Select from "react-select";
import { useStep } from "../../../context/StepContext";

const serviceOptions = [
  { value: "Holiday Camp Booking", label: "Holiday Camp Booking" },
  { value: "Weekly Class Membership", label: "Weekly Class Membership" },
  { value: "Book Free Trial", label: "Book Free Trial" },
  { value: "Add To Waiting List", label: "Add To Waiting List" },
  { value:"One To One", label:"One To One" },
  { value: "Birthday Party", label: "Birthday Party" },
];

export default function ServiceStep() {
  const { formData, setFormData } = useStep();

  return (
    <div className="max-w-[696px] mx-auto poppins">
      <h2 className="md:text-[24px] text-[18px] font-semibold poppins text-center mb-4">
        Which service do you want to use?
      </h2>

      <label className="text-[#282829] poppins text-[16px] block mb-2">
        Select Service
      </label>

      <Select
        options={serviceOptions}
        value={serviceOptions.find(
          (opt) => opt.value === formData.service
        )}
        onChange={(selected) =>
          setFormData({ ...formData, service: selected?.value })
        }
        placeholder="Choose service"
        className="poppins"
        styles={{
          control: (base) => ({
            ...base,
            minHeight: "48px",
            borderRadius: "6px",
            borderColor: "#EBEBEB",
            fontFamily: "poppins",
          }),
          option: (provided, state) => ({
            ...provided,
            fontFamily: "poppins",
          }),
        }}
      />
    </div>
  );
}
